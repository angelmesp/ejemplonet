﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "Adm" And TextBox2.Text = "Adm" Then
            MsgBox("Contraseña correcta")
            Form2.Show()
        Else
            MsgBox("Usuario o contraseña incorrecta")
        End If
    End Sub
End Class
